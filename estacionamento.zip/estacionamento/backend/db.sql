create database estacionamento;
use estacionamento;

create table carros(
	id int auto_increment primary key,
    proprietario varchar(255) not null,
    placa varchar(255) not null,
    modelo varchar(255) not null
);

create table user(
	id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);
