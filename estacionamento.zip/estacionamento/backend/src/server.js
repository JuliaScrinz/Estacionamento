
const express = require('express');
const cors = require('cors');
const connection = require('./db_config');
const app = express();

app.use(cors());
app.use(express.json());

const port = 2008;

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const query = 'SELECT * FROM user WHERE username = ? AND password = ?';
  connection.query(query, [username, password], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro no servidor.' });
    }

    if (results.length > 0) {
      res.json({ success: true, message: 'Login bem-sucedido!' });
    } else {
      res.json({ success: false, message: 'Usuário ou senha incorretos!' });
    }
  });
});


app.post('/carros', (req, res) => {
  const { proprietario, placa, modelo } = req.body;
  const query = 'INSERT INTO carros (proprietario, placa, modelo) VALUES (?, ?, ?)';
  connection.query(query, [proprietario, placa, modelo], (err, result) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro ao inserir carro.' });
    }
    res.json({ success: true, message: 'Carro inserido com sucesso!', id: result.insertId });
  });
});

app.get('/carros', (req, res) => {
  const query = 'SELECT * FROM carros';
  connection.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro ao buscar carro.' });
    }
    res.json({ success: true, products: results });
  });
});

app.put('/carros/:id', (req, res) => {
  const { id } = req.params;
  const { proprietario, placa, modelo } = req.body;
  const query = 'UPDATE carros SET proprietario = ?, placa = ?, modelo = ? WHERE id = ?';
  connection.query(query, [proprietario, placa, modelo, id], (err) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro ao atualizar carro.' });
    }
    res.json({ success: true, message: 'Carro atualizado com sucesso!' });
  });
});

app.delete('/carros/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM carros WHERE id = ?';
  connection.query(query, [id], (err) => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Erro ao deletar carro.' });
    }
    res.json({ success: true, message: 'Carro deletado com sucesso!' });
  });
});

app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));