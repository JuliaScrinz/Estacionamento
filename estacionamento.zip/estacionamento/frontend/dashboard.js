
async function loadProducts() {
    const response = await fetch('http://localhost:2008/carros');
    const data = await response.json();
    const tbody = document.querySelector('tbody');
    tbody.innerHTML = ''; 

    data.products.forEach(product => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${product.id}</td>
        <td>${product.proprietario}</td>
        <td>${product.placa}</td>
        <td>${product.modelo}</td>
        <td>
          <button onclick="editProduct(${product.id})">Editar</button>
          <button onclick="deleteProduct(${product.id})">Excluir</button>
        </td>
      `;
      tbody.appendChild(row);
    });
  }
  

  document.querySelector('.product-form form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const proprietario = document.getElementById('product-name').value;
    const placa = document.getElementById('product-quantity').value;
    const modelo = document.getElementById('product-price').value;
  
    await fetch('http://localhost:2008/carros', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ proprietario, placa, modelo })
    });
  
    document.querySelector('.product-form form').reset();
    loadProducts();
  });
  
  async function deleteProduct(id) {
    await fetch(`http://localhost:2008/carros/${id}`, {
      method: 'DELETE'
    });
    loadProducts();
  }
  

  async function editProduct(id) {
    const proprietario = prompt("Novo nome de proprietário:");
    const placa = prompt("Nova placa do carro:");
    const modelo = prompt("Novo modelo do carro:");
  
    await fetch(`http://localhost:2008/carros/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ proprietario, placa, modelo })
    });
  
    loadProducts();
  }
  
    loadProducts();
  